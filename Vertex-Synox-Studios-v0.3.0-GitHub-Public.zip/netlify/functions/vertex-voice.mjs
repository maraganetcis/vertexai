import { handleVoiceRequest } from './lib/voice-controller.mjs';
import { getAdminServices } from './lib/admin-store.mjs';
// Modern Netlify Functions request/Response API; no public CORS and no URL-based secrets.
export default async function(request){
 try{
  const deps=await getAdminServices();
  return await handleVoiceRequest(request,deps);
 }catch(err){
  // No sensitive request body, tokens or student records in diagnostics.
  console.error('Vertex voice API unavailable');
  return new Response(JSON.stringify({error:'음성 서버 설정 또는 연결을 확인해 주세요.'}),{
   status:503,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}
  });
 }
}
