# DAYMATE AI — Sites 비공개 가져오기 안내

## 목적 및 현재 상태
- **소유자 한 명만** 접근하는 학생용 개인 사이트를 비공개 프로젝트로 생성한다.
- 이 패키지는 실제 DAYMATE AI 웹앱의 HTML/CSS/JS 소스이며, 외부 배포나 Sites 프로젝트 생성은 아직 수행되지 않았다.
- 앱은 기본적으로 `localStorage`에 저장한다. 데이터 키 `daymate-ai-personal-v1` 보존 필수.
- Firebase 설정 파일은 `null`; 실제 로그인·다기기 동기화는 검증되지 않았다.

## Sites에 가져오기 (비공개 상태 유지)
1. ChatGPT의 **Work / Sites** 기능으로 새로운 개인 사이트 프로젝트를 시작한다(지원되는 계정에서).
2. 첨부한 이 ZIP 전체를 업로드하고 다음 요청문을 넣는다.

> 이 ZIP 안의 `index.html`, `app.js`, `style.css`, `sync.js` 등을 그대로 시작 코드로 사용하는 `DAYMATE AI` 개인용 웹사이트를 만들어줘. 모바일 우선, 화이트/스카이블루 유지. 기존 localStorage 키 `daymate-ai-personal-v1`을 변경하거나 초기화하지 마. Firebase 설정 없이 로컬 전용 상태로 만들고, 비공개 미리보기까지만 진행해. 공유 링크 생성, 도메인 연결, 외부 공개 및 Publish/Deploy는 하지 마. 외부 공개가 필요한 작업은 먼저 중단해.

3. 가능하다면 사이트 접근 범위를 **나만/비공개**로 설정한다. 미리보기 URL에 접근 제어가 없으면 개인정보를 입력하지 않는다.
4. 홈/학교/교통/플래너/비서 탭과 과제·일정·노트 CRUD를 테스트한다.
5. 외부 공개, 게시, 퍼블릭 URL 생성, 배포는 운영자 명시 승인이 있기 전 수행하지 않는다.

## 정적 배치 주의
- 앱 시작점: `index.html` (ZIP 루트)
- 필수 파일: `app.js`, `style.css`, `sync.js`, `firebase-config.js`, `sw.js`, `manifest.webmanifest`, `icon.svg`
- 의존성 빌드 없음. Node 내장 HTTP 서버로 로컬 실행: `npm run dev` (기본 4173포트)
- 웹 프로젝트 빌더가 ZIP 루트를 인식하지 못하면 파일을 프로젝트 루트로 복사한다.
- 사이트가 브라우저에서 열리더라도 기존 localhost/local-file 데이터를 자동 이전하지 않는다. 필요한 경우 **원래 앱에서 JSON 내보내기 → 새 사이트에서 JSON 가져오기**를 별도로 실시한다. 다른 출처(origin)의 localStorage는 공유되지 않는다.
- Firebase/NEIS/교통/외부 AI API는 아직 연결되지 않았으며 실시간값이라고 표시하지 않는다.

## 안전 제한
- 현재 `firebase-config.js`는 `window.DAYMATE_FIREBASE_CONFIG = null`이다.
- Firebase 비밀키, 서비스 계정 JSON, 개인 학적·주소·GPS 등 민감정보를 ZIP이나 소스에 기록하지 않는다.
- 인증 없는 미리보기 URL은 절대로 완전한 비공개 저장소가 아니므로, 개인 정보 입력 전 사이트 접근 권한을 확인한다.
- 현 단일 문서 Firestore 동기화는 개별문서 확장 및 실제 인증/규칙 검증이 남아 있다.

## 검사 범위
- `npm test`는 로컬 로직 테스트. 배포된 Sites의 접근 통제·로그인·기기 간 동기화 검증을 대신하지 않는다.
